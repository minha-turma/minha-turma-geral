#!/bin/bash

java -Xmx2G -cp jpretext.jar pretext.Main ./config.ini
